// @vitest-environment jsdom
import { expect, it } from 'vitest'
import { writeFileSync } from 'node:fs'
import rotation from '@gamedata/rotation/bellstrike-bolt/bolt-dummy-1-min.json'
import { buildPresetRotationBundle } from '@/application/graduation'
import { calculateRotationBaseline } from '@/calculations/rotationCalculator'
import { calculateDamageBreakdown as realDamage, type DamageContext } from '@/calculations/damage'
import { defaultGlobalDebuffs } from '@/globalDebuffs'
import { auditTraces, calculateDamageBreakdown as tracedDamage } from './damage-trace'

it('exports and independently reconciles every damage contact',()=>{
 const environment={pathId:'bellstrikeBolt' as const,martialArts:['jueyuXuanfengSpear','boshanQuyueSpear'] as ['jueyuXuanfengSpear','boshanQuyueSpear'],rotation,breakthrough:'19',globalDebuffs:defaultGlobalDebuffs,food:'SimmeringFishSlices',script:'None',divinecraft:'Fire',skillOverrides:{},previewId:null}
 const bundle=buildPresetRotationBundle(environment,'bolt-fully-relayed')!
 const result=calculateRotationBaseline(bundle)
 const rows=new Map(result.timeline.map(row=>[row.id,row]));const contacts=[];let sum=0;let maxError=0
 for(const entry of result.baseline){
  if(entry.action.type!=='damage')continue
  const breakdown=result.actionBreakdowns[entry.id!]!
  const evaluated=realDamage(entry.action,entry.context)
  const error=Math.abs(evaluated.total-breakdown.total);maxError=Math.max(maxError,error)
  expect(error).toBeLessThan(Math.max(1e-8,Math.abs(breakdown.total)*1e-12))
  const branches=[]
  const expand=(context:DamageContext,probability:number)=>{
   const [distribution,...remaining]=context.expectedEffects??[]
   if(distribution){for(const state of distribution)if(state.probability>0)expand({...context,effects:[...context.effects,...state.effects],expectedEffects:remaining},probability*state.probability);return}
   auditTraces.length=0;const traced=tracedDamage(entry.action,context);expect(auditTraces).toHaveLength(1)
   branches.push({probability,...auditTraces[0]})
   expect(Number.isFinite(traced.total)).toBe(true)
  }
  expand(entry.context,1)
  const traceSum=branches.reduce((sum,branch)=>sum+branch.probability*branch.result.total,0)
  expect(Math.abs(traceSum-breakdown.total)).toBeLessThan(Math.max(1e-8,Math.abs(breakdown.total)*1e-12))
  const rowId=entry.id!.slice(0,entry.id!.lastIndexOf(':'));const row=rows.get(rowId)!
  const actionIndex=Number(entry.id!.slice(entry.id!.lastIndexOf(':')+1));const state=row.actionStates[actionIndex]
  const weight=entry.context.skillTags.includes('Mystic')?result.mysticVitalityDamageScale:1
  sum+=breakdown.total*weight
  contacts.push({id:entry.id,rowId,skill:row.step.skill,name:row.skill?.name,shortName:row.skill?.shortName,
   combatTime:entry.timelineTime!-result.anchorTime,castStart:row.startTime-result.anchorTime,
   sourceRowId:entry.sourceRowId,currentMartialArt:state?.currentMartialArt,
   buffs:entry.activeBuffStacks,debuffs:entry.activeDebuffStacks,expectedBuffStacks:breakdown.expectedBuffStacks,
   action:entry.action,context:entry.context,breakdown,finalDamage:breakdown.total*weight,vitalityScale:weight,branches})
 }
 expect(sum).toBeCloseTo(result.metrics.totalDamage,7)
 writeFileSync('local/bolt-report/calculation.json',JSON.stringify({environment,bundle,
  metrics:result.metrics,duration:result.duration,anchorTime:result.anchorTime,mysticVitalityDamageScale:result.mysticVitalityDamageScale,
  verification:{sum,maxError,contactCount:contacts.length,branchCount:contacts.reduce((sum,c)=>sum+c.branches.length,0)},
  timeline:result.timeline.map(row=>({id:row.id,kind:row.kind,step:row.step,start:row.startTime-result.anchorTime,castTime:row.effectiveCastTime,skill:row.skill?.name})),contacts},null,2))
})
