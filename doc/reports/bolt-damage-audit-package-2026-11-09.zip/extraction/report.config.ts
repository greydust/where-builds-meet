import config from "../../vitest.config.ts"
export default { ...config, test: { ...config.test, include: ["local/bolt-report/report.test.ts"] } }
