import collections
import hashlib
import html
import json
import pathlib
import subprocess
from datetime import datetime, timezone

ROOT = pathlib.Path.cwd()
WORK = ROOT / 'local/bolt-report'
OUT = ROOT / 'doc/reports'
OUT.mkdir(exist_ok=True)
raw = json.loads((WORK / 'calculation.json').read_text(encoding='utf-8'))
bundle = raw['bundle']
contacts = raw['contacts']
stem = 'bolt-damage-calculation-2026-11-09'
html_path = OUT / (stem + '.html')
json_path = OUT / (stem + '.json')
E = lambda x: html.escape(str(x), quote=True)
F = lambda x: f'{x:,.6f}'.rstrip('0').rstrip('.') if isinstance(x, (float, int)) else str(x)
P = lambda x: F(x * 100) + '%'
def table(head, rows):
    return '<table border="1" cellpadding="6"><thead><tr>' + ''.join('<th>' + E(x) + '</th>' for x in head) + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join('<td>' + str(x) + '</td>' for x in row) + '</tr>' for row in rows) + '</tbody></table>'
def pre(x):
    return '<pre>' + E(json.dumps(x, ensure_ascii=False, indent=2)) + '</pre>'
def details(label, body):
    return '<details><summary>' + E(label) + '</summary>' + body + '</details>'
def code(x):
    return '<code>' + E(x) + '</code>'

# These are exact runtime definitions, not a second skill database.
catalog = {}
for name in ['jueyu-xuanfeng-spear', 'boshan-quyue-spear']:
    catalog.update(json.loads((ROOT / 'data/skill' / (name + '.json')).read_text(encoding='utf-8')))
used = {c['skill'] for c in contacts}
for key in used:
    if key not in catalog:
        catalog[key] = bundle['timeline']['skills'].get(key, bundle['timeline']['dots'].get(key, {}))

def variant(c):
    key = c['skill']
    if key in ['BoltBlueVC', 'BoltRedVC']:
        return key + ('Sharp' if 'BoltSharpVC' in c['context']['skillTags'] else 'Base')
    return key
groups = collections.defaultdict(list)
for contact in contacts:
    groups[variant(contact)].append(contact)
order = sorted(groups, key=lambda key: -sum(c['finalDamage'] for c in groups[key]))
def label(key):
    s = catalog.get(key, {})
    return (s.get('shortName') or s.get('name') or key) + ' / ' + s.get('name', key)

# Normalize repeated snapshots, aggregates and rule arrays. Every float is retained.
pools = {key: [] for key in ['stats', 'effects', 'aggregates', 'contexts', 'traces']}
indices = {key: {} for key in pools}
def intern(kind, value):
    signature = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    if signature not in indices[kind]:
        indices[kind][signature] = len(pools[kind])
        pools[kind].append(value)
    return indices[kind][signature]
def context_ref(context):
    data = {key: value for key, value in context.items() if key not in ['stats', 'derivedStats', 'effects', 'unconditionalDamageEffects', 'expectedEffects']}
    data['statsRef'] = intern('stats', context['stats'])
    data['derivedStatsRef'] = intern('stats', context['derivedStats'])
    data['effectsRef'] = intern('effects', context['effects'])
    data['aggregateRef'] = intern('aggregates', context.get('unconditionalDamageEffects', {}))
    # Leaves already contain the applicable expected effects; do not replace their
    # distributions with averaged stat values.
    return intern('contexts', data)
compact_contacts = []
for c in contacts:
    data = {key: value for key, value in c.items() if key not in ['branches', 'context']}
    data['variant'] = variant(c)
    data['inputContextRef'] = context_ref(c['context'])
    data['inputExpectedEffects'] = c['context'].get('expectedEffects', [])
    data['branches'] = []
    for t in c['branches']:
        trace = {key: value for key, value in t.items() if key not in ['probability', 'context']}
        trace['contextRef'] = context_ref(t['context'])
        data['branches'].append({'probability': t['probability'], 'traceRef': intern('traces', trace)})
    compact_contacts.append(data)

source_paths = sorted(set([
    'src/calculations/damage.ts', 'src/calculations/actionStats.ts',
    'src/calculations/rotationCalculator.ts', 'src/calculations/rotationTimeline.ts',
    'src/calculations/effectiveStats.ts', 'src/calculations/statEffects.ts',
    'src/calculations/outcomeMachine.ts', 'src/calculations/outcomeStackBuffs.ts',
    'src/calculations/hawkwing.ts',
    'data/attunement.json', 'data/gear-set.json', 'data/system.json',
    'data/breakthrough.json', 'data/arsenal.json', 'data/divinecraft.json', 'data/food.json',
    'data/build/bellstrike-bolt/bolt-fully-relayed.json',
    'data/rotation/bellstrike-bolt/bolt-dummy-1-min.json',
    'data/skill/jueyu-xuanfeng-spear.json', 'data/skill/boshan-quyue-spear.json',
    'data/buff/bellstrike-bolt.json', 'data/debuff/bellstrike-bolt.json',
    'data/martial-art/jueyu-xuanfeng-spear.json', 'data/martial-art/boshan-quyue-spear.json',
] + [str(p.relative_to(ROOT)).replace('\\', '/') for p in (ROOT / 'data/innerway').glob('*.json') if p.stem in ['yue-yong-fang-yuan','shen-duan-qing-feng','fu-liang-yi-ye','ming-fei-tong-pan','sui-xing-qie-tao']]))
sources = [{'path': p, 'sha256': hashlib.sha256((ROOT / p).read_bytes()).hexdigest()} for p in source_paths]
summary = []
for key in order:
    cs = groups[key]
    summary.append({'skillId': key, 'label': label(key), 'damageRows': len(cs),
                    'castRows': len({c['rowId'] for c in cs}),
                    'expectedHits': sum(c['action'].get('hitProbability', 1) for c in cs),
                    'physicalDamage': sum(c['breakdown']['physical'] * c['vitalityScale'] for c in cs),
                    'bellstrikeDamage': sum(c['breakdown']['bellstrike'] * c['vitalityScale'] for c in cs),
                    'totalDamage': sum(c['finalDamage'] for c in cs)})
report = {
    'schemaVersion': 1, 'generatedAtUTC': datetime.now(timezone.utc).isoformat(),
    'purpose': 'Audit of implemented formulas; source correctness is for independent review, not asserted by numerical reconciliation.',
    'gitHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'workingTreeIsDirty': True,
    'environment': raw['environment'], 'metrics': raw['metrics'], 'verification': raw['verification'],
    'duration': raw['duration'], 'anchorTime': raw['anchorTime'],
    'mysticVitalityDamageScale': raw['mysticVitalityDamageScale'],
    'sourceFiles': sources, 'summary': summary, 'catalog': catalog,
    'buildPreset': json.loads((ROOT / 'data/build/bellstrike-bolt/bolt-fully-relayed.json').read_text(encoding='utf-8')),
    'runtimeBundle': bundle, 'timeline': raw['timeline'], 'pools': pools, 'contacts': compact_contacts,
    'normalization': 'Refs are zero-based indices into pools. For each contact, sum(branch.probability * pools.traces[traceRef].result.total), then multiply vitalityScale. action.damageScale already includes any emitted-event probability; do not multiply hitProbability again.',
}
json_path.write_text(json.dumps(report, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')

parts = ['<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Bolt damage calculation audit — 9 November 2026</title><body>',
    '<h1>Bolt (霆) damage calculation audit</h1>',
    '<p>Generated 9 November 2026 from the current dirty workspace. This describes the <strong>implemented calculation</strong> for independent datamine review; exact reconciliation proves that the report matches the simulator, not that every game interpretation is correct.</p>',
    '<p><strong>Fully Relayed Max Build · BT19 · 寒芒 4 · Dummy 1 Min · 40 ms ping</strong><br>月湧方圓 / 神斷青鋒 / 浮梁一夜 / 明非通判, all T6. Simmering Fish Slices, no Script, Fire Divinecraft. Default global debuffs are all inactive. Target: level 96, defense 500, all resistances 0, judgement resistance 0.85. No skill overrides.</p>',
    '<p><strong>' + F(raw['metrics']['dps']) + ' DPS; ' + F(raw['metrics']['totalDamage']) + ' damage / 60 s.</strong> All ' + str(len(contacts)) + ' contact rows were re-evaluated through the production formula and matched with maximum per-contact difference ' + F(raw['verification']['maxError']) + '. ' + str(raw['verification']['branchCount']) + ' resolved probability leaves were traced. Mystic Vitality factor = ' + F(raw['mysticVitalityDamageScale']) + '.</p>',
    '<p>Companion machine-readable artifact: <a href="' + E(json_path.name) + '">' + E(json_path.name) + '</a>. It contains the full runtime input bundle, build gear, all coefficients, every contact and probability leaf, resolved stats/effects, outcome channel results, exact floats, and source hashes.</p>',
    '<nav><a href="#review">Review questions</a> · <a href="#formula">Formula</a> · <a href="#sheet">Sheet</a> · <a href="#boosts">Boost sources</a> · <a href="#summary">Damage totals</a> · <a href="#skills">Per-skill calculations</a> · <a href="#catalog">All Bolt skill data</a> · <a href="#timeline">Rotation</a> · <a href="#provenance">Provenance</a></nav>',
    '<h2 id="review">Questions for the datamine agent</h2><ol>',
    '<li>Confirm Normal CN layer-one, level-100 per-hit coefficients and flat terms, callback counts, and NPC ratio corrections. Ordinary VC +30%, 鋒銳 VC +50%, 鳴戈 +60%, and 鋒銳 T6 +30% currently add in the base-ratio pool. Check whether these belong to the same additive ratio adjustment or require a different composition.</li>',
    '<li>Confirm native event-34 selectors 1/2 for no-flat talents. Runtime multiplies the 1.8 鳴戈 coefficient by 1.015 = 1.827 (and 0.276 載戈 by 1.015), rather than adding 0.015 to the coefficient. Verify the native consumer, not tooltip wording alone.</li>',
    '<li>Confirm 鳴戈 receives 鋒銳, 載戈 10% × stacks, max-Physical talent, full 通判 penetration, and guaranteed Affinity at detonation; confirm source-owner checks and early-Tab/expiry consumption order. All four current detonations observe 15 載戈 stacks and 鋒銳.</li>',
    '<li>Confirm 泉威 = 8% Physical/Bellstrike generally +6% for VC series with 浮梁一夜 T3; blue attack talent applies during 鋒銳 OR to 鳴戈; both are channel bonuses. Check whether the source conditions intentionally admit Flute, Moon procs and Divinecraft.</li>',
    '<li>Confirm HanMang 4, cross-VC buffs, Moon Pull and 載戈 are Category 1; 月湧方圓 T6 DAMAGE_UP is also Category 1 rather than base/Mechanism. Check interaction with existing boss/martial/weapon-art bonuses.</li>',
    '<li>Confirm active-art behavior: shared Blue/Red VC preserves the wielded spear; native Q/Special/Tab changes it. Attunement covers primary VC only, while series bonuses include 載戈/鳴戈. Check the exact native tags.</li>',
    '<li>Review contact schedules and omitted alternatives: 240000113 threefold red-VC branch requires its own buff; unactivated first-light C3 and unsupported red basic-chain identities are not invented. Published animation/contact clocks remain audit-provisional.</li>',
    '<li>Review approved expected approximations separately from native mechanics: expected 月引 extension uses 2 × Affinity chance per qualifying hit; expected 潮湧 is aligned to whole battle seconds; tiny inactive 月相 stack-count mass below 1e-5 promotes upward. Native sampled extensions/timers remain separate.</li>',
    '</ol><p>Defensive/control-only effects and incoming attack classification are outside this outgoing-Dummy-DPS report. No live-game validation or claim of exact native network timing is made.</p>',
    '<h2 id="formula">Exact formula structure used</h2>',
    '<pre>For each resolved probability leaf and outcome o:\n'+
    '  Cp = authored physical coefficient × (1 + no-flat talent), only if BOTH flat terms are zero\n'+
    '  Ca = authored attribute coefficient × the same no-flat factor\n'+
    '  Fp/Fa = authored flat terms × (1 + flat-attack talent)\n'+
    '  penetration(P,R) = 1 + (P−R)/200 if P ≥ R, otherwise 1 + (P−R)/100\n'+
    '  A_o = min attack for Abrasion; mean for Normal/Critical; max for Affinity\n'+
    '  channel raw Physical = [Cp × (A_o × attack bonus − adjusted defense) + Fp]\n'+
    '                         × physical penetration × (1 + physical channel bonus)\n'+
    '  channel raw Bellstrike = [Ca × Bellstrike A_o × attack bonus + Fa]\n'+
    '                           × Bellstrike penetration × (1 + Bellstrike channel bonus) × 1.5\n'+
    '  shared Physical = damageScale × (1 + base bonus) × (1 + Category 1) × (1 + attunement)\n'+
    '  shared Attribute uses Category 1 + attributeDMGBonus in that same bracket\n'+
    '  outcome Physical = max(0, raw Physical × shared Physical × outcome factor × DOT factor × Mechanism)\n'+
    '  outcome Bellstrike = raw Bellstrike × shared Attribute × outcome factor × DOT factor\n'+
    '                       × (Mechanism + Bellstrike Mechanism bonus)\n'+
    '  outcome factor = 1 for Abrasion/Normal, 1 + critical bonus for Critical, 1 + Affinity bonus for Affinity\n'+
    '  Critical bonus clamp: 35%..150%; Affinity bonus clamp: 20%..130%\n'+
    '  leaf damage = Σ(outcome chance × outcome channel damage)\n'+
    '  contact damage = Σ(leaf probability × leaf damage)\n'+
    '  rotation damage = Σ(contact damage × applicable Mystic Vitality factor)\n'+
    '  DPS = rotation damage / 60</pre>',
    '<p>damageScale already contains an emitted proc’s probability. hitProbability is shown for expected counts and trigger admission; it is <strong>not multiplied into damage a second time</strong>. All four attribute channels are evaluated; this build has nonzero Bellstrike only. Void attack is folded into effective Bellstrike before hit evaluation. Defense is subtracted inside the coefficient term, while flat attack is added afterward. Physical damage is clamped per outcome before averaging.</p>',
    '<p>Category 1 = boss bonus + eligible all-Martial-Arts + eligible weapon art + eligible Mystic bonuses + active dmgBonus/hpDMGBonus. The character’s Physical/Bellstrike channel bonuses are separate multiplicative brackets. Mechanism = 1 + globalDmgBonus + globalHPDMGBonus; Bellstrike can add globalBellstrikeDMGBonus. Exhausted contributes +10% Mechanism.</p>',
    '<p>Expected Precision = min(1, (sheet Precision − 0.65)/(1 + 0.85) + 0.65). Effective Crit = min(0.8, sheet Crit / 1.85 + effective Crit bonus). Effective Affinity = min(0.4, sheet Affinity / 1.85). Final Affinity adds Direct Affinity. Crit chance = min(effective Crit + capped Direct Crit, 1 − final Affinity) × effective Precision. Abrasion = (1 − final Affinity) × (1 − effective Precision); Normal receives the remainder. 鋒銳 NoAbrasion sets effective Precision to 1 for matching hits; guaranteed Affinity sets its chance to 1.</p>',
    '<h2 id="sheet">Resolved sheet before temporary combat effects</h2>']
fields = ['minPhys','maxPhys','effectiveMinPhys','effectiveMaxPhys','minBellstrike','maxBellstrike','minVoidAttack','maxVoidAttack','effectiveMinBellstrike','effectiveMaxBellstrike','precision','effectivePrecision','crit','effectiveCrit','affinity','effectiveAffinity','directAffinity','finalAffinity','critDmgBonus','affinityDmgBonus','physDmgBonus','bellstrikeDmgBonus','bellstrikePenetration','physicalPenetration','allMartialArts','vsBossDmg','spearDmgBoost']
parts.append(table(['Field','Exact value'],[(code(k),F(bundle['stats'][k])) for k in fields]))
parts.append('<p>Food adds 140/280 effective Physical Attack. The sheet’s 39.6/39.6 Void Attack adds to Bellstrike. Weapon Physical Penetration attunements total 51.2; four armor VC attunements total 28%. These are held in attunement inputs, not copied into the sheet penetration field. The other four Bolt attunement stats are available but this build has zero rolls in them.</p>')
parts.append('<h2 id="boosts">Named boost sources and how they enter the formula</h2>')
boosts = [
 ('Gear/progression/arsenal','Sheet stats in the preceding table','Raw attack, rates, 7.144% boss, 6.768% martial arts, 6.956% spear; resolved through the shared character pipeline.'),
 ('寒芒 2 / 4','90.6 raw Maximum Physical Attack; +10% HP damage; +5% VC/proc Affinity Damage','The attack is already in the sheet. HP bonus → Category 1. Affinity bonus → outcome bonus, not chance.'),
 ('Fire Divinecraft','+1.5% HP damage and independent Fire/Solid Foundation contacts','Category 1 applies as configured; proc damage is listed separately.'),
 ('Red max-Physical talent','min(floor(action maxPhys / 100) × 1.2%, 18%)','Affinity Damage on full VC series. Current build reaches 18%.'),
 ('Blue max-Physical talent','min(floor(action maxPhys / 125) × 1%, 12%)','Physical/Bellstrike channel bonuses during 鋒銳 OR for 鳴戈. Current build reaches 12%.'),
 ('Blue Bellstrike conversion','min(raw maxBellstrike × 0.000168, 12.6%)','Bellstrike channel bonus, already in sheet. Red penetration conversion caps at 25.2 points.'),
 ('Flat attack / no-flat talent','15% matching current-art flat bonus; 1.5% coefficient multiplier on explicit no-flat effects','15% scales flat terms only. 載戈/鳴戈 have no flats and use the no-flat coefficient enhancement across weapon swaps.'),
 ('神斷青鋒 T0 / T6','+5% Affinity Damage while red; during 鋒銳 both weapons receive it','Series only. Leech is recovery and does not add outgoing damage.'),
 ('鋒銳 + red talent / 神斷 T6','+30% base bonus at T6; +10% Affinity Damage; NoAbrasion','Series only; base bonus joins existing skill NPC base correction.'),
 ('明法 / 重道','Next opposite VC +10% HP damage; another +10% during 鋒銳 at T3','Category 1. Applies to the primary opposite VC tags, not every shared-series proc.'),
 ('浮梁 T4 王行','+3% Direct Affinity against supported boss/Dummy targets','Chance, not Affinity Damage.'),
 ('明非通判 T6','Base +5 penetration; +1 per 通判 stack, plus +2 per stack for VC series','5 stacks give 20 total Physical/all-attribute penetration for VCs/載戈/鳴戈, 10 for other damage. Exact chance distributions are retained.'),
 ('泉威 / 浮梁 T3','+8% Physical/Bellstrike generally; another +6% for VC series','Channel bonuses, not Category 1. Series total 14%; primary VC hits extend the target debuff by 2 s.'),
 ('載戈 stacks','10% × 1..15 stacks','Category 1 for 鳴戈 only; 15 stacks = +150%, not a separate ×2.5 bracket on top of Category 1.'),
 ('月引','+5% HP damage and +1.5% Direct Affinity','Each probability leaf either contains its full bonus or does not. Stats are not averaged before the nonlinear formula.'),
 ('月湧 T3','Additional +1.5% Direct Affinity while 月引 is active','At stable uptime, +3% Direct Affinity total from the Moon branches; with sheet 44.6% and 王行 3%, typical final Affinity is 50.6%.'),
 ('月湧 T6','min(floor(effectiveAffinity / 1%) × 1%, 30%)','Category 1 for 潮湧/洪波萬仞, at cap in this build.'),
 ('Flute','Distance-segment HP damage bonus while Flute is active','Category 1; the 1 m default resolves to 2% under current LowerBoundInclusive lookup. Review this segment convention independently.'),
 ('Exhausted','+10% global damage','Mechanism, separate from Category 1; active snapshots are attached to every contact.'),
 ('VC attunement','4 × 7% = 28%','Standalone ×1.28 on primary light/heavy VC, both ordinary and 鋒銳; 載戈/鳴戈 and Q/Special do not inherit it.'),
]
parts.append(table(['Source','Amount / calculation','Eligibility / pool'],[[E(x) for x in row] for row in boosts]))
parts.append('<p>All named rules and their exact machine predicates are included in runtimeBundle.timeline.setupEffects, innerWayRules, effectDefinitions, and skill modifiers in the JSON. Per-contact leaves record the rules that actually passed, plus aggregate fields. Zero-value/non-damage trigger metadata remains available there.</p>')
parts.append('<h2 id="summary">Damage totals by actual skill variant</h2>')
parts.append(table(['Skill','Rows / contributing cast or emission rows','Expected contacts','Physical','Bellstrike','Total damage','DPS','Share'],[
 [f'<a href="#skill-{E(s["skillId"])}">{E(s["label"])}</a>',f'{s["damageRows"]} / {s["castRows"]}',F(s['expectedHits']),F(s['physicalDamage']),F(s['bellstrikeDamage']),F(s['totalDamage']),F(s['totalDamage']/60),P(s['totalDamage']/raw['metrics']['totalDamage'])] for s in summary]))
parts.append('<p>Rows count modeled damage entries, not successful discrete casts. Expected contacts sum hitProbability. 洪波萬仞’s many initial-trigger probability rows sum to six expected bursts; 潮湧’s early partial-uptime rows sum to ' + F(sum(c['action'].get('hitProbability',1) for c in groups['BoltMoonTide'])) + ' expected ticks. The first cast can include pre-battle hits excluded from this table.</p><h2 id="skills">Per-skill calculations</h2>')

def span(values, percent=False):
    low, high = min(values), max(values)
    fmt = P if percent else F
    return fmt(low) if abs(low-high)<1e-12 else fmt(low)+' … '+fmt(high)
def values_at(cs, path):
    result = []
    for c in cs:
        for t in c['branches']:
            v=t
            for key in path: v=v[key]
            result.append(v)
    return result
def example(c):
    t=max(c['branches'],key=lambda t:t['probability'])
    s=t['context']['stats']; ds=t['context']['derivedStats']; re=t['resolvedEffects']; r=t['rates']
    body='<p>Representative contact '+code(c['id'])+' at '+F(c['combatTime'])+' s; wielding '+E(c.get('currentMartialArt'))+'. Chosen leaf probability '+F(t['probability'])+'. Contact has '+str(len(c['branches']))+' leaves; its full expected damage is '+F(c['finalDamage'])+'. The following arithmetic is for this single leaf, not a falsely averaged state.</p>'
    body+=table(['Input / pool','Resolved value'],[
      ['Physical coefficient',F(c['action'].get('phyCoef',0))+' → '+F(t['coefficient'])],
      ['Attribute coefficient',F(c['action'].get('attrCoef',0))+' → '+F(t['attributeCoefficient'])],
      ['Physical / attribute flat after talent',F(t['physicalBonus'])+' / '+F(t['attributeBonus'])],
      ['Effective Physical min / mean / max', ' / '.join(F(v) for v in [ds['effectiveMinPhys'],(ds['effectiveMinPhys']+ds['effectiveMaxPhys'])/2,ds['effectiveMaxPhys']])],
      ['Effective Bellstrike min / mean / max',' / '.join(F(v) for v in [ds['effectiveMinBellstrike'],(ds['effectiveMinBellstrike']+ds['effectiveMaxBellstrike'])/2,ds['effectiveMaxBellstrike']])],
      ['Physical channel bonus / pen multiplier',P(s['physDmgBonus'])+' / '+F(t['physicalPenetrationMultiplier'])],
      ['Bellstrike channel bonus / pen multiplier / primary attribute multiplier',P(s['bellstrikeDmgBonus'])+' / '+F(t['preparedAttributeRanges'][0]['penetration'])+' / 1.5'],
      ['Adjusted enemy defense',F(t['adjustedEnemyDefense'])],
      ['Base / Category 1 / attunement',P(re['baseDmgBonus'])+' / '+P(t['damageBonusCategory1'])+' / '+P(t['attunementBonus'])],
      ['Shared Physical multiplier',F(t['damageScale'])+' × '+F(1+re['baseDmgBonus'])+' × '+F(1+t['damageBonusCategory1'])+' × '+F(1+t['attunementBonus'])+' = '+F(t['physicalSharedBonus'])],
      ['Mechanism / DOT',F(t['globalMultiplier'])+' / '+F(1+re['dotDamageBonus'])],
      ['Critical / Affinity outcome factors',F(1+t['criticalBonus'])+' / '+F(1+t['affinityBonus'])],
      ['Final outcome chances: Abrasion / Normal / Critical / Affinity',' / '.join(P(r[k]) for k in ['abrasionRate','normalRate','critRate','affinityRate'])],
    ])
    outcomes=t['outcomes']
    body+=table(['Outcome','Chance','Physical damage','Bellstrike damage','Whole-hit damage','Chance × whole hit'],[
     [name,P(r[rate]),F(o['physical']),F(o['bellstrike']),F(sum(o.values())),F(sum(o.values())*r[rate])]
     for name,rate,o in zip(['Abrasion','Normal','Critical','Affinity'],['abrasionRate','normalRate','critRate','affinityRate'],outcomes)])
    body+='<p>Sum = '+F(t['result']['total'])+' for this leaf, already including damageScale. Summing all leaf results × leaf probabilities gives '+F(c['breakdown']['total'])+'; final Mystic scaling ×'+F(c['vitalityScale'])+' gives '+F(c['finalDamage'])+'.</p>'
    # Show a fully substituted formula for the largest contributing outcome.
    oi=max(range(4),key=lambda i:sum(outcomes[i].values())*r[['abrasionRate','normalRate','critRate','affinityRate'][i]])
    mode=['min','mean','mean','max'][oi]; factor=[1,1,1+t['criticalBonus'],1+t['affinityBonus']][oi]
    attack={'min':ds['effectiveMinPhys'],'mean':(ds['effectiveMinPhys']+ds['effectiveMaxPhys'])/2,'max':ds['effectiveMaxPhys']}[mode]
    attr={'min':ds['effectiveMinBellstrike'],'mean':(ds['effectiveMinBellstrike']+ds['effectiveMaxBellstrike'])/2,'max':ds['effectiveMaxBellstrike']}[mode]
    a=t['preparedAttributeRanges'][0]
    body+='<pre>'+E('Dominant outcome: '+['Abrasion','Normal','Critical','Affinity'][oi]+' ('+mode+' attack)\nPhysical = max(0, ['+F(t['coefficient'])+' × ('+F(attack)+' × '+F(t['physicalAttackMultiplier'])+' − '+F(t['adjustedEnemyDefense'])+') + '+F(t['physicalBonus'])+'] × '+F(t['physicalPenetrationMultiplier'])+' × '+F(t['physicalDamageMultiplier'])+' × '+F(t['physicalSharedBonus'])+' × '+F(factor)+' × '+F(1+re['dotDamageBonus'])+' × '+F(t['globalMultiplier'])+') = '+F(outcomes[oi]['physical'])+'\nBellstrike = ['+F(t['attributeCoefficient'])+' × '+F(attr)+' × '+F(a['attackMultiplier'])+' + '+F(a['flatBonus'])+'] × '+F(a['penetration'])+' × '+F(a['damageMultiplier'])+' × '+F(a['pathMultiplier'])+' × '+F(t['attributeSharedBonus'])+' × '+F(factor)+' × '+F(1+re['dotDamageBonus'])+' × '+F(t['globalMultiplier']+re['globalBellstrikeDmgBonus'])+' = '+F(outcomes[oi]['bellstrike']))+'</pre>'
    body+=details('Active tracked stacks for this contact',pre({'buffs':c['buffs'],'debuffs':c['debuffs'],'expectedBuffStacks':c.get('expectedBuffStacks')}))
    # Exclude non-damage event graph metadata from the human-facing list; JSON retains it.
    applicable=[e for e in t['context']['effects'] if any(k in e for k in ['stat','effectiveStat','hpDMGBonus','dmgBonus','baseDMGBonus','affinityDmgBonus','critDmgBonus','physicalPenetration','formlessPenetration','NoAbrasion','GuaranteedAffinity','coefficientBonusWithoutFlatAttack','flatAttackBonus','globalDmgBonus'])]
    body+=details('Applicable effect payloads and static aggregate',pre({'dynamicEffects':applicable,'staticAggregate':t['context'].get('unconditionalDamageEffects',{}),'resolvedDamageEffects':re}))
    return body

for key in order:
    cs=groups[key];definition=catalog.get(key,{})
    parts.append('<section><h3 id="skill-'+E(key)+'">'+E(label(key))+' — '+code(key)+'</h3>')
    parts.append('<p>Actual tags: '+E(', '.join(cs[0]['context']['skillTags']))+'</p>')
    coeffs=collections.Counter(tuple(c['action'].get(k,0) for k in ['phyCoef','phyBonus','attrCoef','attrBonus']) for c in cs)
    parts.append(table(['Authored Physical coef','Physical flat','Attribute coef','Attribute flat','Rows with these inputs'],[[F(x) for x in vals]+[n] for vals,n in coeffs.items()]))
    range_rows=[]
    for title,path,percent in [
      ('Applied coefficient multiplier on no-flat actions',['resolvedEffects','coefficientBonusWithoutFlatAttack'],True),
      ('Applied flat-attack bonus',['resolvedEffects','flatAttackBonus'],True),
      ('Base damage bonus',['resolvedEffects','baseDmgBonus'],True),
      ('Full Category 1 (includes gear and temporary effects)',['damageBonusCategory1'],True),
      ('Attunement bonus',['attunementBonus'],True),
      ('Physical channel bonus',['context','stats','physDmgBonus'],True),
      ('Bellstrike channel bonus',['context','stats','bellstrikeDmgBonus'],True),
      ('Physical penetration multiplier',['physicalPenetrationMultiplier'],False),
      ('Mechanism multiplier',['globalMultiplier'],False),
      ('Affinity Damage bonus after clamp',['affinityBonus'],True),
      ('Final Affinity chance',['rates','affinityRate'],True),
      ('Event damageScale / probability weight',['damageScale'],False),
    ]:range_rows.append([E(title),span(values_at(cs,path),percent)])
    parts.append(table(['Boost / factor','Observed range across all exact leaves'],range_rows))
    parts.append('<p>Ranges describe different hits/probability leaves and must not be multiplied together as if all extrema co-occur. Full per-contact values are in the JSON.</p>')
    parts.append(details('Worked calculation: first contributing contact',example(cs[0])))
    if len(cs)>1 and cs[-1]['id']!=cs[0]['id']:
        parts.append(details('Worked calculation: last contributing contact',example(cs[-1])))
    contact_rows=[]
    for c in cs:
        t=max(c['branches'],key=lambda t:t['probability'])
        contact_rows.append([code(c['id']),F(c['combatTime']),E(c.get('currentMartialArt','—')),F(c['action'].get('hitProbability',1)),str(len(c['branches'])),F(c['breakdown']['physical']),F(c['breakdown']['bellstrike']),F(c['finalDamage']),E(', '.join(f'{k}:{F(v)}' for k,v in (c['debuffs'] or {}).items()))])
    parts.append(details('Every contact: timings, damage and target stacks',table(['ID','Battle seconds','Wielded art','Expected-contact weight','Probability leaves','Physical','Bellstrike','Final damage','Target stacks'],contact_rows)))
    parts.append('</section>')

parts.append('<h2 id="catalog">Complete Bolt skill coefficient catalog</h2><p>Unused skills have no measured damage in this preset. Their coefficient/actions and conditions are exported without inventing an arbitrary combat state. Internal resource-only helper actions remain in the machine-readable catalog.</p>')
for key,s in catalog.items():
    if not key.startswith('Bolt'):continue
    damage_actions=[a for a in s.get('action',[]) if a.get('type')=='damage']
    if not damage_actions and not s.get('subAction') and 'shortName' not in s:continue
    body='<p>Cast duration: '+E(F(s.get('castTime',0)))+' s; contributing rows in rotation: '+str(len(groups.get(key,[])))+'. Native art: '+E(s.get('martialArt','shared / inherited'))+'.</p>'
    body+=table(['Damage action time','Physical coef','Physical flat','Attribute coef','Attribute flat'],[[E(F(a.get('time',0)))]+[E(F(a.get(k,0))) for k in ['phyCoef','phyBonus','attrCoef','attrBonus']] for a in damage_actions])
    body+=pre({k:s[k] for k in ['tags','modifier','subAction','cooldown','cooldownUses','cooldownRecovery','attackResponse'] if k in s})
    body+=details('Complete runtime skill definition',pre(s))
    parts.append(details(label(key)+' — '+key,body))

parts.append('<h2 id="timeline">Authored rotation and actual cast timeline</h2><p>Battle starts at the first Blue VC contact. Negative times are pre-battle setup; their damage before the anchor is excluded. Triggered procs are accounted for in the per-contact sections above. Qi breaks are authored encounter events, not simulated Qi-damage depletion.</p>')
parts.append(table(['Row','Type','Skill / event','Battle time','Effective duration'],[[code(r['id']),E(r['kind']),E(r['step'].get('skill',r['step'].get('event',''))),F(r['start']),F(r['castTime'])] for r in raw['timeline'] if r['kind']=='rotation']))
parts.append('<h2 id="provenance">Provenance and numerical checks</h2><p>Source export: CN Normal layer 1, manifest 94a090d784fc4f1d5dd479ee818d024d3da0c1e6889f89a236da94cdb28f09d9, local/datamine/2026-11-08_18-13-14-875_+0000-RWiW0j. The runtime uses curated data files, not the export directly. Hashes below identify the exact working files used. Git HEAD '+code(report['gitHead'])+' alone is insufficient because the workspace is dirty.</p>')
parts.append(table(['Check','Result'],[['Production action replay max error',F(raw['verification']['maxError'])],['Contacts / probability leaves',str(len(contacts))+' / '+str(raw['verification']['branchCount'])],['Sum final per-contact damage',F(raw['verification']['sum'])],['Published total damage',F(raw['metrics']['totalDamage'])],['Duration / DPS',F(raw['duration'])+' / '+F(raw['metrics']['dps'])]]))
parts.append('<p>Extraction used a local diagnostic copy of damage.ts, with same-directory imports redirected to the original modules. The only formula instrumentation records local variables after the ordinary expected-outcome calculation. No runtime calculation or combat data was changed. Each original entry was also independently re-evaluated through the unmodified production calculateDamageBreakdown function; its result exactly matched the central rotation result. Numerical verification is separate from source-mechanic correctness.</p>')
parts.append(details('File SHA-256 hashes',table(['Path','SHA-256'],[[code(s['path']),code(s['sha256'])] for s in sources])))
parts.append('<h3>Machine-readable navigation</h3><pre>'+E(report['normalization'])+'\ntrace.contextRef → pools.contexts\ncontext.statsRef / derivedStatsRef → pools.stats\ncontext.effectsRef → pools.effects\ncontext.aggregateRef → pools.aggregates\ntrace.outcomes order = [Abrasion, Normal, Critical, Affinity]\nThe context contains fully resolved ordinary/effective stats for that leaf.\ncontact.inputExpectedEffects retains the original full distribution.\nsourceFiles pin implementation/data; runtimeBundle pins the complete calculation inputs.</pre></body></html>')
html_path.write_text('\n'.join(parts),encoding='utf-8')
print(json.dumps({'html':str(html_path),'htmlBytes':html_path.stat().st_size,'json':str(json_path),'jsonBytes':json_path.stat().st_size,'pools':{k:len(v) for k,v in pools.items()},'skills':len(groups)},indent=2))
