import hashlib
import json
import math
import pathlib
import zipfile
from html.parser import HTMLParser

root=pathlib.Path.cwd()
folder=root/'doc/reports'
stem='bolt-damage-calculation-2026-11-09'
data=json.loads((folder/(stem+'.json')).read_text(encoding='utf-8'))
class CheckHTML(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids=set();self.anchors=[];self.titles=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if 'id' in attrs:
            assert attrs['id'] not in self.ids,attrs['id']
            self.ids.add(attrs['id'])
        if tag=='a' and attrs.get('href','').startswith('#'):self.anchors.append(attrs['href'][1:])
check=CheckHTML();check.feed((folder/(stem+'.html')).read_text(encoding='utf-8'))
assert set(check.anchors)<=check.ids
for source in data['sourceFiles']:
    assert hashlib.sha256((root/source['path']).read_bytes()).hexdigest()==source['sha256'],source['path']
expected_total=0
max_error=0
branches=0
for contact in data['contacts']:
    total=0;prob=0
    for branch in contact['branches']:
        t=data['pools']['traces'][branch['traceRef']]
        context=data['pools']['contexts'][t['contextRef']]
        stats=data['pools']['stats'][context['statsRef']]
        derived=data['pools']['stats'][context['derivedStatsRef']]
        assert stats and derived
        for outcome in t['outcomes']:
            assert all(math.isfinite(n) for n in outcome.values())
        reconstructed=0
        for outcome,rate in zip(t['outcomes'],['abrasionRate','normalRate','critRate','affinityRate']):
            reconstructed+=sum(outcome.values())*t['rates'][rate]
        assert math.isclose(reconstructed,t['result']['total'],abs_tol=1e-8,rel_tol=1e-12)
        total+=branch['probability']*t['result']['total'];prob+=branch['probability'];branches+=1
    assert math.isclose(prob,1,abs_tol=1e-12)
    error=abs(total*contact['vitalityScale']-contact['finalDamage']);max_error=max(max_error,error)
    assert math.isclose(total*contact['vitalityScale'],contact['finalDamage'],abs_tol=1e-8,rel_tol=1e-12)
    expected_total+=contact['finalDamage']
assert math.isclose(expected_total,data['metrics']['totalDamage'],abs_tol=1e-7)
assert math.isclose(sum(g['totalDamage'] for g in data['summary']),expected_total,abs_tol=1e-7)
assert math.isclose(expected_total/data['duration'],data['metrics']['dps'],abs_tol=1e-9)

readme='''Bolt (霆) damage calculation audit — 9 November 2026

Open bolt-damage-calculation-2026-11-09.html for the readable report.
The matching JSON contains complete exact runtime inputs and every resolved
contact/probability leaf. It preserves full floating-point values; displayed
HTML numbers are rounded to six decimal places.

Reconciled result: 74,016.13154807402 DPS; 4,440,967.892884441 damage / 60s.
426 damage rows, 837 probability leaves, 16 used skill variants.
Probability emission rows are not additional real casts. See report counts.

This reports implemented behavior for independent audit, not a claim of native
game correctness. Begin with the report's review questions. In particular,
verify coefficient adjustments, ratio composition, bonus categories, source
ownership, proc tags, hit counts and native versus expected-model timing.

implementation/ contains the exact calculator/data files pinned by SHA-256.
extraction/ contains the diagnostic source and verification probe used to
produce this artifact; no runtime calculation files were changed.
The probe uses the repository Vitest environment/aliases and imports the real
calculation pipeline; it is not a standalone simulator.

Extraction: npx vitest run --config local/bolt-report/report.config.ts
Validation: every original action replay matched the central result exactly;
all leaf outcomes and probability sums, skill/contact sums, hashes and HTML
internal links were independently verified. Formatting gate passed.

The accompanying implementation/ files are a working-tree snapshot; the Git
commit alone does not contain the current uncommitted Bolt implementation.
'''
archive=folder/'bolt-damage-audit-package-2026-11-09.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('README.txt',readme)
    for suffix in ['.html','.json']:z.write(folder/(stem+suffix),stem+suffix)
    z.write(root/'doc/bolt-combat-audit.md','bolt-combat-audit.md')
    for source in data['sourceFiles']:z.write(root/source['path'],'implementation/'+source['path'])
    for name in ['damage-trace.ts','report.test.ts','report.config.ts','render.py','verify.py']:
        z.write(root/'local/bolt-report'/name,'extraction/'+name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
print(json.dumps({'contacts':len(data['contacts']),'probabilityLeaves':branches,'skillVariants':len(data['summary']),
 'totalDamage':expected_total,'dps':data['metrics']['dps'],'maxReconstructionError':max_error,
 'sourceHashesChecked':len(data['sourceFiles']),'htmlAnchorsChecked':len(check.anchors),
 'zip':str(archive),'zipBytes':archive.stat().st_size,
 'htmlBytes':(folder/(stem+'.html')).stat().st_size,'jsonBytes':(folder/(stem+'.json')).stat().st_size},indent=2))
