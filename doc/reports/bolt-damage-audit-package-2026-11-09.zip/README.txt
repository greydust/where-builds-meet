Bolt (霆) damage calculation audit — 9 November 2026

Open bolt-damage-calculation-2026-11-09.html for the readable report.
The matching JSON contains complete exact runtime inputs and every resolved
contact/probability leaf. It preserves full floating-point values; displayed
HTML numbers are rounded to six decimal places.

Reconciled result: 74,016.13154807402 DPS; 4,440,967.892884441 damage / 60s.
426 damage rows, 837 probability leaves, 16 used skill variants.
Probability emission rows are not additional real casts. See report counts.

This reports implemented behavior for independent audit, not a claim of native
game correctness. Begin with the report's review questions. In particular,
verify coefficient adjustments, ratio composition, bonus categories, source
ownership, proc tags, hit counts and native versus expected-model timing.

implementation/ contains the exact calculator/data files pinned by SHA-256.
extraction/ contains the diagnostic source and verification probe used to
produce this artifact; no runtime calculation files were changed.
The probe uses the repository Vitest environment/aliases and imports the real
calculation pipeline; it is not a standalone simulator.

Extraction: npx vitest run --config local/bolt-report/report.config.ts
Validation: every original action replay matched the central result exactly;
all leaf outcomes and probability sums, skill/contact sums, hashes and HTML
internal links were independently verified. Formatting gate passed.

The accompanying implementation/ files are a working-tree snapshot; the Git
commit alone does not contain the current uncommitted Bolt implementation.
