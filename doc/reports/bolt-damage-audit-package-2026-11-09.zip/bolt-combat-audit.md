# Bolt combat audit — 9 November 2026

## Scope and source

This audit covers outgoing PvE damage and the resource/buff lifecycle of the
Bolt preview, including the four equipped Inner Ways, selectable 歲星竊桃,
both martial-art talent tables, supported skill routes, all five attunements,
and 寒芒. The reference is CN Normal layer 1, manifest
`94a090d784fc4f1d5dd479ee818d024d3da0c1e6889f89a236da94cdb28f09d9`,
exported under
`local/datamine/2026-11-08_18-13-14-875_+0000-RWiW0j`.
The export is local investigation input, not a runtime dependency.

Primary records are `wwm-skills-normal-all.json`,
`wwm-skills-inner-way-all.json`, `wwm-martial-arts-normal.json`,
`wwm-inner-way-normal.json`, `wwm-attunements-cn.json`, `wwm-item-sets.json`,
`buff.json`, `buff_passive_data.json`, and `passive_skills.json`.
The source research repository's `notes/bolt-timings.md`,
`notes/yueyong-proc-timing.md`, and `notes/divinecraft.md` establish the
route, periodic-clock, and event-effect interpretations used here.

## Corrections

| Mechanic                   | Correct behavior and evidence                                                                                                                                                                                                                                   |
| -------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 泉威                       | Source 4040171 grants 8% Physical/Bellstrike channel damage to the applier's damage generally. 4040172 adds another 6% to the VC series with 浮梁一夜 T3. Replaces 10% plus 4%, both formerly restricted to VCs.                                                |
| 載戈 stacks                | 4040191 uses incoming adjustment event 1, 10% per stack, restricted to 鳴戈 2020420501 and the applier. This joins Category 1 (`hpDMGBonus`), separate from 鳴戈's 60% NPC base bonus and 鋒銳's base bonus. Explicit 1–15 stack effects are retained.          |
| 通判 T6                    | 102753511–515 add two penetration per stack to the complete VC series, including 載戈 and 鳴戈, rather than primary VCs alone. The ordinary one per stack and base five remain.                                                                                 |
| Blue attack-scaling talent | 32320111/20211/20311 use **鋒銳 OR 鳴戈**, without a primary-VC restriction. Each complete 125 Maximum Physical Attack grants 1% Physical/Bellstrike channel damage, capped at 4%/8%/12% for ranks 2–5/6–7/8+. The formula remains live at the action snapshot. |
| Red Affinity-damage talent | 32220111/20211/20311 grant 1.2% per complete 100 Maximum Physical Attack to the VC series, capped at 6%/12%/18% at the same rank boundaries. Previously missing lower-rank variants are present; continuous interpolation is removed.                           |
| Rank-zero 鋒銳             | 322501 already grants the 15% NPC base bonus and 10% Affinity Damage. Abrasion immunity arrives with upgraded 322502 at rank 5. 神斷青鋒 T6 replaces the 15% base bonus with 30%.                                                                               |
| 王行                       | 323501 grants 12 seconds; upgraded 323502 grants 24 seconds from talent rank 5.                                                                                                                                                                                 |
| No-flat proc enhancement   | 32250221/31 and subsequent ranks select the no-flat proc tags without a current-art condition. 載戈/鳴戈 retain this enhancement after switching to blue. Current-art gating remains on ordinary flat-attack bonuses.                                           |
| 月湧方圓 T6 damage         | 10216014 writes `DAMAGE_UP`, a Category 1 bonus, rather than the NPC/base multiplier. Each complete percentage point of effective Affinity grants 1%, capped at 30%. This applies to both 潮湧 and 洪波萬仞.                                                    |

Event 1 maps to `_effect_event_adj_dmg`; incoming trigger 3 adjusts damage
parameters, including stack multiplication. It is the same additive family as
Soul-Shaken. `DAMAGE_UP` adds beside `play_cause_up_rate` in the ordinary
damage formula. Neither belongs to cause-50/Mechanism. Event 34's base-ratio
adjustments remain in `baseDMGBonus`.

## Verified behavior retained

| Area     | Audit result                                                                                                                                                                                                                                                                                                          |
| -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 神斷青鋒 | Current-art Affinity Damage/leech, opposite-VC 明法/重道 bonuses, T3 enhancement, T4 duration/refill cooldown, and T6 cost/base-bonus replacement are represented.                                                                                                                                                    |
| 浮梁一夜 | Initial +2 槍勢, enhanced blue parry/refollow, exit +2, T3 duration and 泉威 extension, 王行 Direct Affinity, and T6 載戈/guaranteed-Affinity 鳴戈 are represented. All four preset detonations observe 15 stacks before consumption and retain 鋒銳 at damage settlement.                                            |
| 明非通判 | Base and stacked penetration, Affinity-dependent applications, T4 guaranteed VC/proc applications and 10-second duration, and T6 series enhancement are represented. Chance and guaranteed applications share the existing numeric outcome-stack tracker.                                                             |
| 月湧方圓 | 月相 activation, 月引 extension/HP cost, 暗潮, 潮信, 潮湧 carrier, initial direct-hit burst, and ten-Tide repeat counter are represented. The initial burst is additional and does not reset the repeat counter.                                                                                                      |
| 歲星竊桃 | Same-weapon martial-art bonus, Mystic penalty and immunity during 竊桃, on-Tab application/cooldown, Tab damage bonus, and T6 duration/additional martial damage are represented for Bolt's locked spear pair.                                                                                                        |
| T2/T5    | All five Inner Ways use the shared raw-stat pipeline and source Solo Level tables.                                                                                                                                                                                                                                    |
| Skills   | Level-100 ordinary Q/Special/Tab/charged and selectable basic coefficients match their source curves. Ordinary and 鋒銳 VC primary hits, contact 載戈, and 鳴戈 are separate identities. NPC Q/VC base corrections remain separate from ordinary damage bonuses. Zero-damage collision markers are not extra attacks. |
| Talents  | Rank-specific raw attributes, Momentum conversions, Bellstrike conversion, flat attack and no-flat proc enhancement are present. The shared Bellstrike primary-attribute multiplier already supplies the 50% attribute enhancement; it is not added twice.                                                            |
| Gear     | 寒芒 4 retains the two-piece Maximum Physical Attack plus its same-weapon HP-damage and VC/proc Affinity Damage bonuses. All five attunements use native category/tag matching; the build retains four VC attunements.                                                                                                |
| Rotation | Four 鋒銳 windows complete before the 60-second cutoff; 王行 covers the martial hits. Flute Cancel → Deflect after editor #21 and the final Red Heavy 1 are retained.                                                                                                                                                 |

## Model boundaries

This is an outgoing-DPS audit, not a claim that the simulator models every
defensive or control mechanic. Incoming attacks currently carry no martial-art,
Mystic, or multiplayer-boss classification. Consequently the conditional
defensive portions of 歲星竊桃, blue 王行's multiplayer-boss reduction, and
cast-only control/mitigation effects are not represented as unconditional
reductions. They do not raise this passive Dummy's outgoing damage.

The approved expected-value 月引 extension, whole-battle-second expected 潮湧
clock, and tiny 月相 probability promotion remain deliberate approximations;
sampled fights retain native extensions and carrier-relative ticks.
Animation/contact clocks remain source `audit-provisional`, with nominal
immediate eligible contact and no inferred native network delay.
Unsupported red basic-chain identities and the unactivated C3 collision are
not fabricated. The separate 240000113 threefold red-VC branch requires its
own buff; it is not applied to the ordinary preset.

`tests/bolt-audit.test.ts` verifies the corrected mechanics through observable
damage and buff duration. The existing Bolt combat, Moon, stats, and attunement
tests cover their shared integration. No accepted DPS snapshot is rewritten by
this audit.

The production calculator's Fully Relayed BT19 result on Dummy 1 Min changes
from 70,316.54681955876 to 74,016.13154807402 DPS (+5.2613%). This comparison
uses Simmering Fish Slices, no Script, Fire Divinecraft, the default global
debuff selections, and no skill overrides. Duration and primary red/blue VC
hit counts are unchanged. The four 鳴戈 detonations rise from 604,184.0093 to
736,223.6684 total damage, chiefly from the corrected stack category and T6
penetration. The other gains come from corrected damage scopes and proc talents;
the 月湧方圓 category correction is included in the same result.
